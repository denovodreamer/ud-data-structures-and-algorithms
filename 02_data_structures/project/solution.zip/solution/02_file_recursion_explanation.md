

The search within directories is done using recursion.

The worst case scenario is the largest depth of directories within directories.