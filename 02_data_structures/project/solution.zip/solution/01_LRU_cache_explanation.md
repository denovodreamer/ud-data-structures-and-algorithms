

A linked list is used to build the cache, along with a hash map in parallel.

This way, the lookup operation takes O(1), and to insert and remove elements takes also O(1).