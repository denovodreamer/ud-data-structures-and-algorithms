

The chosen structures were a linked list for the priority queue, and a binary search tree for the Huffman tree.

The worst case scenario is O(n), because it's necessary to traverse all the characters from the message.