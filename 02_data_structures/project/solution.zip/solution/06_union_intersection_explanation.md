
Linked lists are used for the input and output.

A hash map is used to keep track of the occurrences of each element on each list.

Since each linked list is traversed, the worst case is O(n+m) where n and m are the lengths of each linked list in the input.